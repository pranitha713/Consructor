 public class cons {
  int c,d,n=5;

     cons() {

        for (int i = 0; i < n; i++) {
            if (i < 3)
                System.out.println("*");
            else {
                System.out.println("#");

            }
        }
    }
     void show()
     {
         System.out.println("printed all starts, hash");

     }
    cons(int d) {
        this.c = c;
        c = d+5;
    }
    void display() {
        System.out.println("sum of two numbers is :" +c);
    }

    public static void main(String[] args) {
        cons c1 = new cons();
       cons c0 = new cons(5);
        c0.display();
        c1.show();



    }

}
